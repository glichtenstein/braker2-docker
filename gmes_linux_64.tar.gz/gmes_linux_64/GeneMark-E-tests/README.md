# GeneMark.hmm Example

Test examples for eukaryotic GeneMark.hmm which serve to:

  * Demonstrate the usage of GeneMark.hmm
  * To test whether the program is correctly installed

# GeneMark-E* Examples

Test examples for eukaryotic GeneMark-E* which serve to:

  * Demonstrate the usage of GeneMark-E*
  * To test whether the program is correctly configured

